#pragma once

#include "mbr.h"

void
DumpMbr(
    IN      PMBR        Mbr
    );