#pragma once

#include "io.h"
#include "../../Volume/headers/volume_structures.h"

void
DumpVolume(
    IN      PVOLUME     Volume
    );