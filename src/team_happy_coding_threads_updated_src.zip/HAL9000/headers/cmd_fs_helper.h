#pragma once

#include "cmd_common.h"

FUNC_GenericCommand CmdStatFile;
FUNC_GenericCommand CmdMakeDirectory;
FUNC_GenericCommand CmdMakeFile;
FUNC_GenericCommand CmdListDirectory;
FUNC_GenericCommand CmdReadFile;
FUNC_GenericCommand CmdWriteFile;
FUNC_GenericCommand CmdSwap;
