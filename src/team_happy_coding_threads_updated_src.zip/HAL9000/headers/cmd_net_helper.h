#pragma once

#include "cmd_common.h"

FUNC_GenericCommand CmdListNetworks;
FUNC_GenericCommand CmdNetRecv;
FUNC_GenericCommand CmdNetSend;
FUNC_GenericCommand CmdChangeDevStatus;