#pragma once

typedef struct _PROCESS* PPROCESS;

void
DumpProcess(
    IN  PPROCESS    Process
    );