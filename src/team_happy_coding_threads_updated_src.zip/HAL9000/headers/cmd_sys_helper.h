#pragma once

#include "cmd_common.h"

FUNC_GenericCommand CmdDisplaySysInfo;
FUNC_GenericCommand CmdSetIdle;
FUNC_GenericCommand CmdGetIdle;
FUNC_GenericCommand CmdResetSystem;
FUNC_GenericCommand CmdShutdownSystem;
